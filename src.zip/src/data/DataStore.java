package data;

import model.*;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * DataStore class manages all data persistence and business logic
 * Implements Singleton pattern to ensure single instance
 */
public class DataStore {
    private static DataStore instance;

    // Data storage directories
    private static final String DATA_DIR = "data";
    private static final String USERS_FILE = DATA_DIR + "/users.txt";
    private static final String STUDENTS_FILE = DATA_DIR + "/students.txt";
    private static final String COURSES_FILE = DATA_DIR + "/courses.txt";
    private static final String ENROLLMENTS_FILE = DATA_DIR + "/enrollments.txt";
    private static final String GRADES_FILE = DATA_DIR + "/grades.txt";

    // In-memory data structures
    private List<User> users;
    private List<StudentProfile> students;
    private List<Course> courses;
    private List<Enrollment> enrollments;
    private List<GradeRecord> grades;

    /**
     * Private constructor for Singleton pattern
     */
    private DataStore() {
        users = new ArrayList<>();
        students = new ArrayList<>();
        courses = new ArrayList<>();
        enrollments = new ArrayList<>();
        grades = new ArrayList<>();
        initialize();
    }

    /**
     * Get the singleton instance of DataStore
     */
    public static DataStore getInstance() {
        if (instance == null) {
            instance = new DataStore();
        }
        return instance;
    }

    /**
     * Initialize the data store by creating directory and loading data
     */
    public void initialize() {
        try {
            // Create data directory if it doesn't exist
            File dataDir = new File(DATA_DIR);
            if (!dataDir.exists()) {
                dataDir.mkdirs();
            }

            // Load all data from files
            loadUsers();
            loadStudents();
            loadCourses();
            loadEnrollments();
            loadGrades();

            // Create default admin if no users exist
            if (users.isEmpty()) {
                createDefaultData();
            }
        } catch (Exception e) {
            System.err.println("Error initializing DataStore: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Create default data for testing
     */
    private void createDefaultData() {
        // Create default admin
        User admin = new User("admin", "admin123", "Admin", "System Administrator", "ADMIN001");
        users.add(admin);
        saveUsers();
        System.out.println("Default admin created: username=admin, password=admin123");
    }

    // ==================== Authentication ====================

    /**
     * Authenticate a user with username and password
     */
    public User authenticate(String username, String password) {
        if (username == null || password == null) {
            return null;
        }

        for (User user : users) {
            if (user.getUsername().equals(username) && user.getPassword().equals(password)) {
                return user;
            }
        }
        return null;
    }

    // ==================== User Management ====================

    /**
     * Find user by username
     */
    public User findUser(String username) {
        if (username == null) return null;
        return users.stream()
                .filter(u -> u.getUsername().equals(username))
                .findFirst()
                .orElse(null);
    }

    /**
     * Add a new user
     */
    public boolean addUser(User user) {
        if (user == null || user.getUsername() == null || user.getUsername().trim().isEmpty()) {
            return false;
        }

        // Check if username already exists
        if (findUser(user.getUsername()) != null) {
            return false;
        }

        users.add(user);
        saveUsers();
        return true;
    }

    /**
     * Get all users
     */
    public List<User> getUsers() {
        return new ArrayList<>(users);
    }

    // ==================== Student Management ====================

    /**
     * Find student profile by username
     */
    public StudentProfile findStudentProfileByUsername(String username) {
        if (username == null) return null;
        return students.stream()
                .filter(s -> s.getUsername().equals(username))
                .findFirst()
                .orElse(null);
    }

    /**
     * Find student profile by student ID
     */
    public StudentProfile findStudentProfileById(String studentId) {
        if (studentId == null) return null;
        return students.stream()
                .filter(s -> s.getStudentId().equals(studentId))
                .findFirst()
                .orElse(null);
    }

    /**
     * Add a new student profile
     */
    public boolean addStudentProfile(StudentProfile student) {
        if (student == null || student.getStudentId() == null || student.getStudentId().trim().isEmpty()) {
            return false;
        }

        // Check if student ID already exists
        if (findStudentProfileById(student.getStudentId()) != null) {
            return false;
        }

        students.add(student);
        saveStudents();
        return true;
    }

    /**
     * Get all students
     */
    public List<StudentProfile> getStudents() {
        return new ArrayList<>(students);
    }

    // ==================== Course Management ====================

    /**
     * Find course by course code
     */
    public Course findCourse(String courseCode) {
        if (courseCode == null) return null;
        return courses.stream()
                .filter(c -> c.getCourseCode().equals(courseCode))
                .findFirst()
                .orElse(null);
    }

    /**
     * Add a new course
     */
    public boolean addCourse(Course course) {
        if (course == null || course.getCourseCode() == null || course.getCourseCode().trim().isEmpty()) {
            return false;
        }

        // Check if course code already exists
        if (findCourse(course.getCourseCode()) != null) {
            return false;
        }

        courses.add(course);
        saveCourses();
        return true;
    }

    /**
     * Get all courses
     */
    public List<Course> getCourses() {
        return new ArrayList<>(courses);
    }

    /**
     * Get courses by instructor username
     */
    public List<Course> getCoursesByInstructor(String instructorUsername) {
        if (instructorUsername == null) return new ArrayList<>();
        return courses.stream()
                .filter(c -> c.getInstructorUsername().equals(instructorUsername))
                .collect(Collectors.toList());
    }

    // ==================== Enrollment Management ====================

    /**
     * Count enrollments for a course
     */
    public int countEnrollmentForCourse(String courseCode) {
        if (courseCode == null) return 0;
        return (int) enrollments.stream()
                .filter(e -> e.getCourseCode().equals(courseCode))
                .count();
    }

    /**
     * Check if student is already enrolled in a course
     */
    public boolean isStudentEnrolled(String studentUsername, String courseCode) {
        if (studentUsername == null || courseCode == null) return false;
        return enrollments.stream()
                .anyMatch(e -> e.getStudentUsername().equals(studentUsername) 
                        && e.getCourseCode().equals(courseCode));
    }

    /**
     * Enroll a student in a course
     */
    public boolean enrollStudent(String studentUsername, String courseCode) {
        // Validate inputs
        if (studentUsername == null || courseCode == null) {
            return false;
        }

        // Check if course exists
        Course course = findCourse(courseCode);
        if (course == null) {
            return false;
        }

        // Check if already enrolled
        if (isStudentEnrolled(studentUsername, courseCode)) {
            return false;
        }

        // Check quota
        int currentEnrollments = countEnrollmentForCourse(courseCode);
        if (currentEnrollments >= course.getQuota()) {
            return false;
        }

        // Add enrollment
        Enrollment enrollment = new Enrollment(studentUsername, courseCode);
        enrollments.add(enrollment);
        saveEnrollments();
        return true;
    }

    /**
     * Get enrollments for a student
     */
    public List<Enrollment> getEnrollmentsByStudent(String studentUsername) {
        if (studentUsername == null) return new ArrayList<>();
        return enrollments.stream()
                .filter(e -> e.getStudentUsername().equals(studentUsername))
                .collect(Collectors.toList());
    }

    /**
     * Get enrollments for a course
     */
    public List<Enrollment> getEnrollmentsByCourse(String courseCode) {
        if (courseCode == null) return new ArrayList<>();
        return enrollments.stream()
                .filter(e -> e.getCourseCode().equals(courseCode))
                .collect(Collectors.toList());
    }

    /**
     * Remove enrollment
     */
    public boolean removeEnrollment(String studentUsername, String courseCode) {
        if (studentUsername == null || courseCode == null) return false;
        
        boolean removed = enrollments.removeIf(e -> 
            e.getStudentUsername().equals(studentUsername) && 
            e.getCourseCode().equals(courseCode));
        
        if (removed) {
            saveEnrollments();
        }
        return removed;
    }

    // ==================== Grade Management ====================

    /**
     * Find grade record
     */
    public GradeRecord findGrade(String studentUsername, String courseCode) {
        if (studentUsername == null || courseCode == null) return null;
        return grades.stream()
                .filter(g -> g.getStudentUsername().equals(studentUsername) 
                        && g.getCourseCode().equals(courseCode))
                .findFirst()
                .orElse(null);
    }

    /**
     * Insert or update grade
     */
    public boolean upsertGrade(String studentUsername, String courseCode, double midterm, double finalExam) {
        // Validate inputs
        if (studentUsername == null || courseCode == null) {
            return false;
        }

        if (midterm < 0 || midterm > 100 || finalExam < 0 || finalExam > 100) {
            return false;
        }

        // Check if student is enrolled in the course
        if (!isStudentEnrolled(studentUsername, courseCode)) {
            return false;
        }

        // Find existing grade
        GradeRecord existing = findGrade(studentUsername, courseCode);

        if (existing != null) {
            // Update existing grade
            existing.setMidterm(midterm);
            existing.setFinalExam(finalExam);
        } else {
            // Create new grade record
            GradeRecord newGrade = new GradeRecord(studentUsername, courseCode, midterm, finalExam);
            grades.add(newGrade);
        }

        saveGrades();
        return true;
    }

    /**
     * Get grades for a student
     */
    public List<GradeRecord> getGradesByStudent(String studentUsername) {
        if (studentUsername == null) return new ArrayList<>();
        return grades.stream()
                .filter(g -> g.getStudentUsername().equals(studentUsername))
                .collect(Collectors.toList());
    }

    /**
     * Calculate GPA for a student
     */
    public double calculateGPA(String studentUsername) {
        List<GradeRecord> studentGrades = getGradesByStudent(studentUsername);
        
        if (studentGrades.isEmpty()) {
            return 0.0;
        }

        double totalPoints = 0.0;
        int totalCredits = 0;

        for (GradeRecord grade : studentGrades) {
            Course course = findCourse(grade.getCourseCode());
            if (course != null) {
                totalPoints += grade.getGradePoint() * course.getCredit();
                totalCredits += course.getCredit();
            }
        }

        if (totalCredits == 0) {
            return 0.0;
        }

        return totalPoints / totalCredits;
    }

    // ==================== File I/O Operations ====================

    /**
     * Save users to file
     */
    public void saveUsers() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(USERS_FILE))) {
            for (User user : users) {
                writer.write(user.toFileString());
                writer.newLine();
            }
        } catch (IOException e) {
            System.err.println("Error saving users: " + e.getMessage());
        }
    }

    /**
     * Load users from file
     */
    public void loadUsers() {
        users.clear();
        File file = new File(USERS_FILE);
        if (!file.exists()) {
            return;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                User user = User.fromFileString(line);
                if (user != null) {
                    users.add(user);
                }
            }
        } catch (IOException e) {
            System.err.println("Error loading users: " + e.getMessage());
        }
    }

    /**
     * Save students to file
     */
    public void saveStudents() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(STUDENTS_FILE))) {
            for (StudentProfile student : students) {
                writer.write(student.toFileString());
                writer.newLine();
            }
        } catch (IOException e) {
            System.err.println("Error saving students: " + e.getMessage());
        }
    }

    /**
     * Load students from file
     */
    public void loadStudents() {
        students.clear();
        File file = new File(STUDENTS_FILE);
        if (!file.exists()) {
            return;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                StudentProfile student = StudentProfile.fromFileString(line);
                if (student != null) {
                    students.add(student);
                }
            }
        } catch (IOException e) {
            System.err.println("Error loading students: " + e.getMessage());
        }
    }

    /**
     * Save courses to file
     */
    public void saveCourses() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(COURSES_FILE))) {
            for (Course course : courses) {
                writer.write(course.toFileString());
                writer.newLine();
            }
        } catch (IOException e) {
            System.err.println("Error saving courses: " + e.getMessage());
        }
    }

    /**
     * Load courses from file
     */
    public void loadCourses() {
        courses.clear();
        File file = new File(COURSES_FILE);
        if (!file.exists()) {
            return;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                Course course = Course.fromFileString(line);
                if (course != null) {
                    courses.add(course);
                }
            }
        } catch (IOException e) {
            System.err.println("Error loading courses: " + e.getMessage());
        }
    }

    /**
     * Save enrollments to file
     */
    public void saveEnrollments() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(ENROLLMENTS_FILE))) {
            for (Enrollment enrollment : enrollments) {
                writer.write(enrollment.toFileString());
                writer.newLine();
            }
        } catch (IOException e) {
            System.err.println("Error saving enrollments: " + e.getMessage());
        }
    }

    /**
     * Load enrollments from file
     */
    public void loadEnrollments() {
        enrollments.clear();
        File file = new File(ENROLLMENTS_FILE);
        if (!file.exists()) {
            return;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                Enrollment enrollment = Enrollment.fromFileString(line);
                if (enrollment != null) {
                    enrollments.add(enrollment);
                }
            }
        } catch (IOException e) {
            System.err.println("Error loading enrollments: " + e.getMessage());
        }
    }

    /**
     * Save grades to file
     */
    public void saveGrades() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(GRADES_FILE))) {
            for (GradeRecord grade : grades) {
                writer.write(grade.toFileString());
                writer.newLine();
            }
        } catch (IOException e) {
            System.err.println("Error saving grades: " + e.getMessage());
        }
    }

    /**
     * Load grades from file
     */
    public void loadGrades() {
        grades.clear();
        File file = new File(GRADES_FILE);
        if (!file.exists()) {
            return;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                GradeRecord grade = GradeRecord.fromFileString(line);
                if (grade != null) {
                    grades.add(grade);
                }
            }
        } catch (IOException e) {
            System.err.println("Error loading grades: " + e.getMessage());
        }
    }
}
