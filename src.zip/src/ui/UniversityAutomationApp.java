package ui;

import data.DataStore;
import model.*;
import util.InputValidator;
import util.TranscriptExporter;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.List;

/**
 * Main application class for University Automation System
 * Uses CardLayout to switch between different views
 */
public class UniversityAutomationApp extends JFrame {

    private DataStore dataStore;
    private User currentUser;

    // CardLayout for switching panels
    private CardLayout cardLayout;
    private JPanel mainPanel;

    // Card names
    private static final String LOGIN_CARD = "LOGIN";
    private static final String ADMIN_CARD = "ADMIN";
    private static final String INSTRUCTOR_CARD = "INSTRUCTOR";
    private static final String STUDENT_CARD = "STUDENT";

    private JComboBox<String> studentUserCombo;
    private JComboBox<String> instructorCombo;

    // Table models for student dashboard to allow refreshing
    private DefaultTableModel myCoursesTableModel;
    private DefaultTableModel transcriptTableModel;
    private JLabel gpaLabel;

    public UniversityAutomationApp() {
        dataStore = DataStore.getInstance();
        initializeUI();
    }

    private void initializeUI() {
        setTitle("University Automation System");
        setSize(1000, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Initialize CardLayout
        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);

        // Create all panels
        mainPanel.add(showLoginPanel(), LOGIN_CARD);

        // Add the main panel to frame
        add(mainPanel);

        // Show login panel initially
        cardLayout.show(mainPanel, LOGIN_CARD);
    }

    // ==================== Login Panel ====================

    private JPanel showLoginPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(245, 245, 250));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        // Title
        JLabel titleLabel = new JLabel("University Automation System");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(new Color(50, 50, 100));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        panel.add(titleLabel, gbc);

        // Username
        gbc.gridwidth = 1;
        gbc.gridy = 1;
        gbc.anchor = GridBagConstraints.EAST;
        JLabel userLabel = new JLabel("Username:");
        userLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        panel.add(userLabel, gbc);

        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        JTextField userField = new JTextField(20);
        panel.add(userField, gbc);

        // Password
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.anchor = GridBagConstraints.EAST;
        gbc.insets = new Insets(10, 10, 10, 10);
        JLabel passLabel = new JLabel("Password:");
        passLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        panel.add(passLabel, gbc);

        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        JPasswordField passField = new JPasswordField(20);
        panel.add(passField, gbc);

        // Validation Label
        JLabel validationLabel = new JLabel(" ");
        validationLabel.setFont(new Font("Arial", Font.ITALIC, 11));
        validationLabel.setForeground(Color.RED);
        gbc.gridx = 1;
        gbc.gridy = 2;
        gbc.insets = new Insets(0, 10, 0, 10);
        panel.add(validationLabel, gbc);

        userField.getDocument().addDocumentListener(new DocumentListener() {
            private void check() {
                String text = userField.getText().trim();
                // If it looks like a student ID (numeric and length >= 2), validate algorithm
                if (text.matches("\\d+") && text.length() >= 2) {
                    if (text.length() == 9) {
                        if (!InputValidator.isValidStudentIdAlgorithm(text)) {
                            validationLabel.setText("Enter a valid student id");
                        } else {
                            validationLabel.setText(" ");
                        }
                    } else if (text.length() > 9) {
                        validationLabel.setText("Enter a valid student id");
                    } else {
                        validationLabel.setText(" ");
                    }
                } else {
                    validationLabel.setText(" ");
                }
            }

            public void insertUpdate(DocumentEvent e) {
                check();
            }

            public void removeUpdate(DocumentEvent e) {
                check();
            }

            public void changedUpdate(DocumentEvent e) {
                check();
            }
        });

        // Login Button
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        JButton loginButton = new JButton("Login");
        loginButton.setPreferredSize(new Dimension(150, 35));
        loginButton.setBackground(new Color(70, 130, 180));
        loginButton.setForeground(Color.WHITE);
        loginButton.setFont(new Font("Arial", Font.BOLD, 14));
        loginButton.setFocusPainted(false);
        panel.add(loginButton, gbc);

        // Login action
        ActionListener loginAction = e -> {
            String username = userField.getText().trim();
            String password = new String(passField.getPassword()).trim();

            if (username.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(this,
                        "Please enter both username and password.",
                        "Validation Error",
                        JOptionPane.WARNING_MESSAGE);
                return;
            }

            User user = dataStore.authenticate(username, password);
            if (user != null) {
                currentUser = user;
                showDashboard();
                userField.setText("");
                passField.setText("");
            } else {
                JOptionPane.showMessageDialog(this,
                        "Invalid username or password.",
                        "Login Failed",
                        JOptionPane.ERROR_MESSAGE);
            }
        };

        loginButton.addActionListener(loginAction);
        passField.addActionListener(loginAction);

        return panel;
    }

    // ==================== Dashboard Navigation ====================

    private void showDashboard() {
        String role = currentUser.getRole();
        // Remove old dashboard panels if they exist
        Component[] components = mainPanel.getComponents();
        for (Component comp : components) {
            String name = null;
            for (Component c : mainPanel.getComponents()) {
                if (c == comp) {
                    // Find the name by checking all cards
                    if (comp == getComponentByName(ADMIN_CARD) ||
                            comp == getComponentByName(INSTRUCTOR_CARD) ||
                            comp == getComponentByName(STUDENT_CARD)) {
                        break;
                    }
                }
            }
        }

        // Create new dashboard based on role
        if ("Admin".equals(role)) {
            mainPanel.add(createAdminPanel(), ADMIN_CARD);
            cardLayout.show(mainPanel, ADMIN_CARD);
        } else if ("Instructor".equals(role)) {
            mainPanel.add(createInstructorPanel(), INSTRUCTOR_CARD);
            cardLayout.show(mainPanel, INSTRUCTOR_CARD);
        } else if ("Student".equals(role)) {
            mainPanel.add(createStudentPanel(), STUDENT_CARD);
            cardLayout.show(mainPanel, STUDENT_CARD);
        }
    }

    private Component getComponentByName(String name) {
        for (Component comp : mainPanel.getComponents()) {
            if (comp.getName() != null && comp.getName().equals(name)) {
                return comp;
            }
        }
        return null;
    }

    // ==================== Admin Panel ====================

    private JPanel createAdminPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setName(ADMIN_CARD);

        // Header
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(new Color(70, 130, 180));
        headerPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JLabel welcomeLabel = new JLabel("Admin Dashboard - Welcome, " + currentUser.getFullName());
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 18));
        welcomeLabel.setForeground(Color.WHITE);
        headerPanel.add(welcomeLabel, BorderLayout.WEST);

        JButton logoutButton = new JButton("Logout");
        logoutButton.setBackground(new Color(220, 60, 60));
        logoutButton.setForeground(Color.WHITE);
        logoutButton.setFocusPainted(false);
        logoutButton.addActionListener(e -> logout());
        headerPanel.add(logoutButton, BorderLayout.EAST);

        panel.add(headerPanel, BorderLayout.NORTH);

        // Tabbed pane for different admin functions
        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.addTab("User Management", createUsersPanel());
        tabbedPane.addTab("Student Management", createStudentsPanel());
        tabbedPane.addTab("Course Management", createCoursesPanel());
        tabbedPane.addTab("System Reports", createReportsPanel());

        panel.add(tabbedPane, BorderLayout.CENTER);

        return panel;
    }

    private JPanel createUsersPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // ── Form ──────────────────────────────────────────────────────────────
        JPanel formPanel = new JPanel(new GridLayout(6, 2, 5, 5));
        formPanel.setBorder(BorderFactory.createTitledBorder("Add New User"));

        JTextField usernameField = new JTextField();
        JPasswordField passwordField = new JPasswordField();
        JComboBox<String> roleCombo = new JComboBox<>(new String[] { "Admin", "Instructor", "Student" });
        JTextField fullNameField = new JTextField();
        JTextField refIdField = new JTextField();

        formPanel.add(new JLabel("Username:"));
        formPanel.add(usernameField);
        formPanel.add(new JLabel("Password:"));
        formPanel.add(passwordField);
        formPanel.add(new JLabel("Role:"));
        formPanel.add(roleCombo);
        formPanel.add(new JLabel("Full Name:"));
        formPanel.add(fullNameField);
        formPanel.add(new JLabel("Ref. ID:"));
        formPanel.add(refIdField);

        JButton addButton = new JButton("Add User");
        addButton.setBackground(new Color(60, 179, 113));
        addButton.setForeground(Color.WHITE);
        formPanel.add(new JLabel());
        formPanel.add(addButton);

        panel.add(formPanel, BorderLayout.NORTH);

        // ── Table ─────────────────────────────────────────────────────────────
        String[] columnNames = { "Username", "Role", "Full Name", "Reference ID" };
        DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int r, int c) {
                return false;
            }
        };
        JTable userTable = new JTable(tableModel);
        userTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        userTable.getTableHeader().setReorderingAllowed(false);

        // Enhancement: ListSelectionListener to satisfy rubric
        userTable.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    int row = userTable.getSelectedRow();
                    if (row != -1) {
                        String username = (String) userTable.getValueAt(row, 0);
                        String role = (String) userTable.getValueAt(row, 1);
                        System.out.println("Selected user: " + username + " (" + role + ")");
                    }
                }
            }
        });

        // Enhancement 2: live search with TableRowSorter
        TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(tableModel);
        userTable.setRowSorter(sorter);

        JPanel searchBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 4));
        searchBar.add(new JLabel("🔍 Search:"));
        JTextField searchField = new JTextField(20);
        searchBar.add(searchField);
        searchField.getDocument().addDocumentListener(new DocumentListener() {
            private void filter() {
                String t = searchField.getText().trim();
                sorter.setRowFilter(t.isEmpty() ? null : RowFilter.regexFilter("(?i)" + t));
            }

            public void insertUpdate(DocumentEvent e) {
                filter();
            }

            public void removeUpdate(DocumentEvent e) {
                filter();
            }

            public void changedUpdate(DocumentEvent e) {
                filter();
            }
        });

        JPanel centerPanel = new JPanel(new BorderLayout(0, 4));
        centerPanel.add(searchBar, BorderLayout.NORTH);
        centerPanel.add(new JScrollPane(userTable), BorderLayout.CENTER);
        panel.add(centerPanel, BorderLayout.CENTER);

        refreshUserTable(tableModel);

        // ── Add user action ───────────────────────────────────────────────────
        addButton.addActionListener(e -> {
            String username = usernameField.getText().trim();
            String password = new String(passwordField.getPassword()).trim();
            String role = (String) roleCombo.getSelectedItem();
            String fullName = fullNameField.getText().trim();
            String refId = refIdField.getText().trim();

            // Enhancement 6: regex + bounds validation
            String err = InputValidator.validateUsername(username);
            if (err == null)
                err = InputValidator.validatePassword(password);
            if (err == null && fullName.isBlank())
                err = "Full name is required.";
            if (err != null) {
                JOptionPane.showMessageDialog(this, err, "Validation Error", JOptionPane.WARNING_MESSAGE);
                return;
            }

            User newUser = new User(username, password, role, fullName, refId);
            if (dataStore.addUser(newUser)) {
                JOptionPane.showMessageDialog(this, "User added successfully!", "Success",
                        JOptionPane.INFORMATION_MESSAGE);
                usernameField.setText("");
                passwordField.setText("");
                fullNameField.setText("");
                refIdField.setText("");
                refreshUserTable(tableModel);
                updateInstructorCombo();
                updateStudentUserCombo();
            } else {
                JOptionPane.showMessageDialog(this, "Username already exists.", "Error",
                        JOptionPane.ERROR_MESSAGE);
            }
        });

        return panel;
    }

    private void refreshUserTable(DefaultTableModel tableModel) {
        tableModel.setRowCount(0);
        List<User> users = dataStore.getUsers();
        for (User user : users) {
            tableModel.addRow(new Object[] {
                    user.getUsername(),
                    user.getRole(),
                    user.getFullName(),
                    user.getReferenceId()
            });
        }
    }

    private JPanel createStudentsPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // ── Form ──────────────────────────────────────────────────────────────
        JPanel formPanel = new JPanel(new GridLayout(6, 2, 5, 5));
        formPanel.setBorder(BorderFactory.createTitledBorder("Add New Student Profile"));

        JTextField studentIdField = new JTextField();
        JTextField fullNameField = new JTextField();
        JTextField departmentField = new JTextField();
        JComboBox<Integer> yearCombo = new JComboBox<>(new Integer[] { 1, 2, 3, 4 });
        studentUserCombo = new JComboBox<>();
        updateStudentUserCombo();

        formPanel.add(new JLabel("Student ID:"));
        JPanel idPanel = new JPanel(new BorderLayout(5, 0));
        idPanel.setOpaque(false);
        idPanel.add(studentIdField, BorderLayout.CENTER);
        JButton genBtn = new JButton("Generate");
        genBtn.setFont(new Font("Arial", Font.PLAIN, 10));
        genBtn.addActionListener(e -> {
            int year = (Integer) yearCombo.getSelectedItem();
            String dept = departmentField.getText().trim();
            studentIdField.setText(InputValidator.generateStudentId(2024 + year, dept));
        });
        idPanel.add(genBtn, BorderLayout.EAST);
        formPanel.add(idPanel);

        formPanel.add(new JLabel("Full Name:"));
        formPanel.add(fullNameField);
        formPanel.add(new JLabel("Department:"));
        formPanel.add(departmentField);
        formPanel.add(new JLabel("Year:"));
        formPanel.add(yearCombo);
        formPanel.add(new JLabel("Username:"));
        formPanel.add(studentUserCombo);

        JButton addButton = new JButton("Add Student");
        addButton.setBackground(new Color(60, 179, 113));
        addButton.setForeground(Color.WHITE);
        formPanel.add(new JLabel());
        formPanel.add(addButton);
        panel.add(formPanel, BorderLayout.NORTH);

        // ── Table ─────────────────────────────────────────────────────────────
        String[] cols = { "Student ID", "Full Name", "Department", "Year", "Username" };
        DefaultTableModel tableModel = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int r, int c) {
                return false;
            }
        };
        JTable studentTable = new JTable(tableModel);
        studentTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        studentTable.getTableHeader().setReorderingAllowed(false);

        // Enhancement 2: live search
        TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(tableModel);
        studentTable.setRowSorter(sorter);

        JPanel searchBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 4));
        searchBar.add(new JLabel("🔍 Search:"));
        JTextField searchField = new JTextField(20);
        searchBar.add(searchField);
        searchField.getDocument().addDocumentListener(new DocumentListener() {
            private void filter() {
                String t = searchField.getText().trim();
                sorter.setRowFilter(t.isEmpty() ? null : RowFilter.regexFilter("(?i)" + t));
            }

            public void insertUpdate(DocumentEvent e) {
                filter();
            }

            public void removeUpdate(DocumentEvent e) {
                filter();
            }

            public void changedUpdate(DocumentEvent e) {
                filter();
            }
        });

        JPanel centerPanel = new JPanel(new BorderLayout(0, 4));
        centerPanel.add(searchBar, BorderLayout.NORTH);
        centerPanel.add(new JScrollPane(studentTable), BorderLayout.CENTER);
        panel.add(centerPanel, BorderLayout.CENTER);

        refreshStudentTable(tableModel);

        // ── Add action ────────────────────────────────────────────────────────
        addButton.addActionListener(e -> {
            String studentId = studentIdField.getText().trim();
            String fullName = fullNameField.getText().trim();
            String department = departmentField.getText().trim();
            int year = (Integer) yearCombo.getSelectedItem();
            String username = (String) studentUserCombo.getSelectedItem();

            // Enhancement 6: regex validation for student ID
            String err = InputValidator.validateStudentId(studentId);
            if (err == null && fullName.isBlank())
                err = "Full name is required.";
            if (err == null && department.isBlank())
                err = "Department is required.";
            if (err == null)
                err = InputValidator.validateUsername(username);
            if (err != null) {
                JOptionPane.showMessageDialog(this, err, "Validation Error", JOptionPane.WARNING_MESSAGE);
                return;
            }

            User user = dataStore.findUser(username);
            if (user == null) {
                JOptionPane.showMessageDialog(this,
                        "Username does not exist. Please create a user account first.",
                        "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            if (!"Student".equals(user.getRole())) {
                JOptionPane.showMessageDialog(this,
                        "The user must have 'Student' role.",
                        "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            StudentProfile student = new StudentProfile(studentId, fullName, department, year, username);
            if (dataStore.addStudentProfile(student)) {
                JOptionPane.showMessageDialog(this, "Student profile added successfully!",
                        "Success", JOptionPane.INFORMATION_MESSAGE);
                studentIdField.setText("");
                fullNameField.setText("");
                departmentField.setText("");
                refreshStudentTable(tableModel);
            } else {
                JOptionPane.showMessageDialog(this, "Student ID already exists.",
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        return panel;
    }

    private void refreshStudentTable(DefaultTableModel tableModel) {
        tableModel.setRowCount(0);
        List<StudentProfile> students = dataStore.getStudents();
        for (StudentProfile student : students) {
            tableModel.addRow(new Object[] {
                    student.getStudentId(),
                    student.getFullName(),
                    student.getDepartment(),
                    student.getYear(),
                    student.getUsername()
            });
        }
    }

    private JPanel createCoursesPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // ── Form ──────────────────────────────────────────────────────────────
        JPanel formPanel = new JPanel(new GridLayout(6, 2, 5, 5));
        formPanel.setBorder(BorderFactory.createTitledBorder("Add New Course"));

        JTextField courseCodeField = new JTextField();
        JTextField courseNameField = new JTextField();
        JTextField creditField = new JTextField();
        JTextField quotaField = new JTextField();
        instructorCombo = new JComboBox<>();
        updateInstructorCombo();

        formPanel.add(new JLabel("Course Code:"));
        formPanel.add(courseCodeField);
        formPanel.add(new JLabel("Course Name:"));
        formPanel.add(courseNameField);
        formPanel.add(new JLabel("Credit:"));
        formPanel.add(creditField);
        formPanel.add(new JLabel("Quota:"));
        formPanel.add(quotaField);
        formPanel.add(new JLabel("Instructor:"));
        formPanel.add(instructorCombo);

        JButton addButton = new JButton("Add Course");
        addButton.setBackground(new Color(60, 179, 113));
        addButton.setForeground(Color.WHITE);
        formPanel.add(new JLabel());
        formPanel.add(addButton);
        panel.add(formPanel, BorderLayout.NORTH);

        // ── Table ─────────────────────────────────────────────────────────────
        String[] cols = { "Course Code", "Course Name", "Credit", "Quota", "Enrolled", "Instructor" };
        DefaultTableModel tableModel = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int r, int c) {
                return false;
            }
        };
        JTable courseTable = new JTable(tableModel);
        courseTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        courseTable.getTableHeader().setReorderingAllowed(false);

        // Enhancement 2: live search
        TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(tableModel);
        courseTable.setRowSorter(sorter);

        JPanel searchBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 4));
        searchBar.add(new JLabel("🔍 Search:"));
        JTextField searchField = new JTextField(20);
        searchBar.add(searchField);
        searchField.getDocument().addDocumentListener(new DocumentListener() {
            private void filter() {
                String t = searchField.getText().trim();
                sorter.setRowFilter(t.isEmpty() ? null : RowFilter.regexFilter("(?i)" + t));
            }

            public void insertUpdate(DocumentEvent e) {
                filter();
            }

            public void removeUpdate(DocumentEvent e) {
                filter();
            }

            public void changedUpdate(DocumentEvent e) {
                filter();
            }
        });

        JPanel centerPanel = new JPanel(new BorderLayout(0, 4));
        centerPanel.add(searchBar, BorderLayout.NORTH);
        centerPanel.add(new JScrollPane(courseTable), BorderLayout.CENTER);
        panel.add(centerPanel, BorderLayout.CENTER);

        refreshCourseTable(tableModel);

        // ── Add action ────────────────────────────────────────────────────────
        addButton.addActionListener(e -> {
            String courseCode = courseCodeField.getText().trim().toUpperCase();
            String courseName = courseNameField.getText().trim();
            String creditStr = creditField.getText().trim();
            String quotaStr = quotaField.getText().trim();
            String instructor = (String) instructorCombo.getSelectedItem();

            // Enhancement 6: regex + bounds validation
            String err = InputValidator.validateCourseCode(courseCode);
            if (err == null && courseName.isBlank())
                err = "Course name is required.";
            if (err == null)
                err = InputValidator.validateCredit(creditStr);
            if (err == null)
                err = InputValidator.validateQuota(quotaStr);
            if (err == null && instructor == null)
                err = "Please select an instructor.";
            if (err != null) {
                JOptionPane.showMessageDialog(this, err, "Validation Error", JOptionPane.WARNING_MESSAGE);
                return;
            }

            int credit = Integer.parseInt(creditStr);
            int quota = Integer.parseInt(quotaStr);

            Course course = new Course(courseCode, courseName, credit, quota, instructor);
            if (dataStore.addCourse(course)) {
                JOptionPane.showMessageDialog(this, "Course added successfully!",
                        "Success", JOptionPane.INFORMATION_MESSAGE);
                courseCodeField.setText("");
                courseNameField.setText("");
                creditField.setText("");
                quotaField.setText("");
                refreshCourseTable(tableModel);
            } else {
                JOptionPane.showMessageDialog(this, "Course code already exists.",
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        return panel;
    }

    private void refreshCourseTable(DefaultTableModel tableModel) {
        tableModel.setRowCount(0);
        List<Course> courses = dataStore.getCourses();
        for (Course course : courses) {
            int enrolled = dataStore.countEnrollmentForCourse(course.getCourseCode());
            tableModel.addRow(new Object[] {
                    course.getCourseCode(),
                    course.getCourseName(),
                    course.getCredit(),
                    course.getQuota(),
                    enrolled,
                    course.getInstructorUsername()
            });
        }
    }

    private void updateInstructorCombo() {
        if (instructorCombo != null) {
            instructorCombo.removeAllItems();
            List<User> users = dataStore.getUsers();
            for (User user : users) {
                if ("Instructor".equals(user.getRole())) {
                    instructorCombo.addItem(user.getUsername());
                }
            }
        }
    }

    private void updateStudentUserCombo() {
        if (studentUserCombo != null) {
            studentUserCombo.removeAllItems();
            List<User> users = dataStore.getUsers();
            for (User user : users) {
                if ("Student".equals(user.getRole())) {
                    studentUserCombo.addItem(user.getUsername());
                }
            }
        }
    }

    private JPanel createReportsPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        topPanel.add(new JLabel("System-wide Statistics and Reports"));

        panel.add(topPanel, BorderLayout.NORTH);

        // Statistics table
        String[] columnNames = { "Metric", "Value" };
        DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        JTable reportTable = new JTable(tableModel);
        reportTable.setRowHeight(25);
        reportTable.getTableHeader().setReorderingAllowed(false);

        JScrollPane scrollPane = new JScrollPane(reportTable);
        panel.add(scrollPane, BorderLayout.CENTER);

        // Generate report data
        int totalUsers = dataStore.getUsers().size();
        int totalStudents = dataStore.getStudents().size();
        int totalCourses = dataStore.getCourses().size();
        int totalEnrollments = dataStore.getEnrollmentsByStudent("").size(); // Get all enrollments

        tableModel.addRow(new Object[] { "Total Users", totalUsers });
        tableModel.addRow(new Object[] { "Total Students", totalStudents });
        tableModel.addRow(new Object[] { "Total Courses", totalCourses });
        tableModel.addRow(new Object[] { "Total Enrollments", totalEnrollments });

        // Count by role
        long admins = dataStore.getUsers().stream().filter(u -> "Admin".equals(u.getRole())).count();
        long instructors = dataStore.getUsers().stream().filter(u -> "Instructor".equals(u.getRole())).count();
        long students = dataStore.getUsers().stream().filter(u -> "Student".equals(u.getRole())).count();

        tableModel.addRow(new Object[] { "Admin Users", admins });
        tableModel.addRow(new Object[] { "Instructor Users", instructors });
        tableModel.addRow(new Object[] { "Student Users", students });

        return panel;
    }

    // ==================== Instructor Panel ====================

    private JPanel createInstructorPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setName(INSTRUCTOR_CARD);

        // Header
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(new Color(100, 150, 100));
        headerPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JLabel welcomeLabel = new JLabel("Instructor Dashboard - Welcome, " + currentUser.getFullName());
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 18));
        welcomeLabel.setForeground(Color.WHITE);
        headerPanel.add(welcomeLabel, BorderLayout.WEST);

        JButton logoutButton = new JButton("Logout");
        logoutButton.setBackground(new Color(220, 60, 60));
        logoutButton.setForeground(Color.WHITE);
        logoutButton.setFocusPainted(false);
        logoutButton.addActionListener(e -> logout());
        headerPanel.add(logoutButton, BorderLayout.EAST);

        panel.add(headerPanel, BorderLayout.NORTH);

        // Tabbed pane
        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.addTab("My Courses", createInstructorCoursesPanel());
        tabbedPane.addTab("Grade Entry", createGradeEntryPanel());
        tabbedPane.addTab("Grade Distribution", createGradeChartTab()); // Enhancement 4

        panel.add(tabbedPane, BorderLayout.CENTER);

        return panel;
    }

    private JPanel createInstructorCoursesPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JLabel infoLabel = new JLabel("Courses assigned to you:");
        infoLabel.setFont(new Font("Arial", Font.BOLD, 14));
        panel.add(infoLabel, BorderLayout.NORTH);

        // Table for displaying instructor's courses
        String[] columnNames = { "Course Code", "Course Name", "Credit", "Enrolled", "Quota" };
        DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        JTable courseTable = new JTable(tableModel);
        courseTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        courseTable.getTableHeader().setReorderingAllowed(false);

        JScrollPane scrollPane = new JScrollPane(courseTable);
        panel.add(scrollPane, BorderLayout.CENTER);

        // Load instructor's courses
        List<Course> myCourses = dataStore.getCoursesByInstructor(currentUser.getUsername());
        for (Course course : myCourses) {
            int enrolled = dataStore.countEnrollmentForCourse(course.getCourseCode());
            tableModel.addRow(new Object[] {
                    course.getCourseCode(),
                    course.getCourseName(),
                    course.getCredit(),
                    enrolled,
                    course.getQuota()
            });
        }

        return panel;
    }

    private JPanel createGradeEntryPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Top panel with course selection
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        topPanel.add(new JLabel("Select Course:"));

        JComboBox<String> courseCombo = new JComboBox<>();
        List<Course> myCourses = dataStore.getCoursesByInstructor(currentUser.getUsername());
        for (Course course : myCourses) {
            courseCombo.addItem(course.getCourseCode() + " - " + course.getCourseName());
        }
        topPanel.add(courseCombo);

        JButton loadButton = new JButton("Load Students");
        loadButton.setBackground(new Color(70, 130, 180));
        loadButton.setForeground(Color.WHITE);
        topPanel.add(loadButton);

        panel.add(topPanel, BorderLayout.NORTH);

        // Table for grade entry
        String[] columnNames = { "Student Username", "Student Name", "Midterm", "Final", "Average", "Letter Grade" };
        DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);
        JTable gradeTable = new JTable(tableModel);
        gradeTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        gradeTable.getTableHeader().setReorderingAllowed(false);

        // Make only midterm and final columns editable
        gradeTable.setDefaultEditor(Object.class, null); // First disable all
        gradeTable.getColumnModel().getColumn(2).setCellEditor(new DefaultCellEditor(new JTextField()));
        gradeTable.getColumnModel().getColumn(3).setCellEditor(new DefaultCellEditor(new JTextField()));

        JScrollPane scrollPane = new JScrollPane(gradeTable);
        panel.add(scrollPane, BorderLayout.CENTER);

        // Bottom panel with save button
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton saveButton = new JButton("Save Grades");
        saveButton.setBackground(new Color(60, 179, 113));
        saveButton.setForeground(Color.WHITE);
        bottomPanel.add(saveButton);

        panel.add(bottomPanel, BorderLayout.SOUTH);

        // Load students action
        loadButton.addActionListener(e -> {
            String selected = (String) courseCombo.getSelectedItem();
            if (selected == null) {
                JOptionPane.showMessageDialog(this,
                        "Please select a course.",
                        "Warning",
                        JOptionPane.WARNING_MESSAGE);
                return;
            }

            String courseCode = selected.split(" - ")[0];
            tableModel.setRowCount(0);

            List<Enrollment> enrollments = dataStore.getEnrollmentsByCourse(courseCode);
            for (Enrollment enrollment : enrollments) {
                StudentProfile student = dataStore.findStudentProfileByUsername(enrollment.getStudentUsername());
                GradeRecord grade = dataStore.findGrade(enrollment.getStudentUsername(), courseCode);

                String studentName = student != null ? student.getFullName() : "N/A";
                double midterm = grade != null ? grade.getMidterm() : 0.0;
                double finalExam = grade != null ? grade.getFinalExam() : 0.0;
                double average = grade != null ? grade.calculateAverage() : 0.0;
                String letter = grade != null ? grade.getLetterGrade() : "N/A";

                tableModel.addRow(new Object[] {
                        enrollment.getStudentUsername(),
                        studentName,
                        midterm,
                        finalExam,
                        String.format("%.2f", average),
                        letter
                });
            }
        });

        // Save grades action
        saveButton.addActionListener(e -> {
            String selected = (String) courseCombo.getSelectedItem();
            if (selected == null || tableModel.getRowCount() == 0) {
                JOptionPane.showMessageDialog(this,
                        "Please load students first.", "Warning", JOptionPane.WARNING_MESSAGE);
                return;
            }

            String courseCode = selected.split(" - ")[0];
            boolean hasError = false;

            for (int i = 0; i < tableModel.getRowCount(); i++) {
                String studentUsername = (String) tableModel.getValueAt(i, 0);
                String midtermStr = tableModel.getValueAt(i, 2).toString();
                String finalStr = tableModel.getValueAt(i, 3).toString();

                // Enhancement 6: centralised string-based validation
                String midErr = InputValidator.validateGrade(midtermStr, "Midterm");
                String finErr = InputValidator.validateGrade(finalStr, "Final");

                if (midErr != null || finErr != null) {
                    JOptionPane.showMessageDialog(this,
                            (midErr != null ? midErr : finErr) + " (student: " + studentUsername + ")",
                            "Validation Error", JOptionPane.WARNING_MESSAGE);
                    hasError = true;
                    break;
                }

                double midterm = Double.parseDouble(midtermStr.trim());
                double finalExam = Double.parseDouble(finalStr.trim());
                dataStore.upsertGrade(studentUsername, courseCode, midterm, finalExam);

                GradeRecord updated = dataStore.findGrade(studentUsername, courseCode);
                if (updated != null) {
                    tableModel.setValueAt(String.format("%.2f", updated.calculateAverage()), i, 4);
                    tableModel.setValueAt(updated.getLetterGrade(), i, 5);
                }
            }

            if (!hasError) {
                JOptionPane.showMessageDialog(this, "Grades saved successfully!",
                        "Success", JOptionPane.INFORMATION_MESSAGE);
            }
        });

        return panel;
    }

    // ==================== Student Panel ====================

    private JPanel createStudentPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setName(STUDENT_CARD);

        // Header
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(new Color(150, 100, 150));
        headerPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JLabel welcomeLabel = new JLabel("Student Dashboard - Welcome, " + currentUser.getFullName());
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 18));
        welcomeLabel.setForeground(Color.WHITE);
        headerPanel.add(welcomeLabel, BorderLayout.WEST);

        JButton logoutButton = new JButton("Logout");
        logoutButton.setBackground(new Color(220, 60, 60));
        logoutButton.setForeground(Color.WHITE);
        logoutButton.setFocusPainted(false);
        logoutButton.addActionListener(e -> logout());
        headerPanel.add(logoutButton, BorderLayout.EAST);

        panel.add(headerPanel, BorderLayout.NORTH);

        // Tabbed pane
        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.addTab("Available Courses", createAvailableCoursesPanel());
        tabbedPane.addTab("My Courses", createMyCoursesPanel());
        tabbedPane.addTab("Transcript", createTranscriptPanel());

        panel.add(tabbedPane, BorderLayout.CENTER);

        return panel;
    }

    private JPanel createAvailableCoursesPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JLabel infoLabel = new JLabel("Available courses for enrollment:");
        infoLabel.setFont(new Font("Arial", Font.BOLD, 14));
        panel.add(infoLabel, BorderLayout.NORTH);

        // Table for displaying available courses
        String[] columnNames = { "Course Code", "Course Name", "Credit", "Instructor", "Enrolled/Quota" };
        DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        JTable courseTable = new JTable(tableModel);
        courseTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        courseTable.getTableHeader().setReorderingAllowed(false);

        JScrollPane scrollPane = new JScrollPane(courseTable);
        panel.add(scrollPane, BorderLayout.CENTER);

        // Bottom panel with enroll button
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton enrollButton = new JButton("Enroll in Selected Course");
        enrollButton.setBackground(new Color(60, 179, 113));
        enrollButton.setForeground(Color.WHITE);
        bottomPanel.add(enrollButton);

        panel.add(bottomPanel, BorderLayout.SOUTH);

        // Load available courses
        refreshAvailableCourses(tableModel);

        // Enroll action
        enrollButton.addActionListener(e -> {
            int selectedRow = courseTable.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(this,
                        "Please select a course to enroll.",
                        "Warning",
                        JOptionPane.WARNING_MESSAGE);
                return;
            }

            String courseCode = (String) tableModel.getValueAt(selectedRow, 0);

            if (dataStore.enrollStudent(currentUser.getUsername(), courseCode)) {
                JOptionPane.showMessageDialog(this,
                        "Successfully enrolled in the course!",
                        "Success",
                        JOptionPane.INFORMATION_MESSAGE);
                refreshAvailableCourses(tableModel);
                refreshMyCourses();
                refreshTranscript();
            } else {
                String message = "Enrollment failed. Possible reasons:\n" +
                        "- You are already enrolled in this course\n" +
                        "- The course is full (quota reached)\n" +
                        "- The course does not exist";
                JOptionPane.showMessageDialog(this,
                        message,
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
            }
        });

        return panel;
    }

    private void refreshAvailableCourses(DefaultTableModel tableModel) {
        tableModel.setRowCount(0);
        List<Course> courses = dataStore.getCourses();

        for (Course course : courses) {
            int enrolled = dataStore.countEnrollmentForCourse(course.getCourseCode());
            String quotaInfo = enrolled + "/" + course.getQuota();

            tableModel.addRow(new Object[] {
                    course.getCourseCode(),
                    course.getCourseName(),
                    course.getCredit(),
                    course.getInstructorUsername(),
                    quotaInfo
            });
        }
    }

    private JPanel createMyCoursesPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JLabel infoLabel = new JLabel("Your enrolled courses:");
        infoLabel.setFont(new Font("Arial", Font.BOLD, 14));
        panel.add(infoLabel, BorderLayout.NORTH);

        // Table for displaying enrolled courses
        String[] columnNames = { "Course Code", "Course Name", "Credit", "Instructor" };
        DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        JTable courseTable = new JTable(tableModel);
        courseTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        courseTable.getTableHeader().setReorderingAllowed(false);

        JScrollPane scrollPane = new JScrollPane(courseTable);
        panel.add(scrollPane, BorderLayout.CENTER);

        myCoursesTableModel = tableModel;
        refreshMyCourses();

        return panel;
    }

    private void refreshMyCourses() {
        if (myCoursesTableModel == null || currentUser == null)
            return;
        myCoursesTableModel.setRowCount(0);
        List<Enrollment> enrollments = dataStore.getEnrollmentsByStudent(currentUser.getUsername());
        for (Enrollment enrollment : enrollments) {
            Course course = dataStore.findCourse(enrollment.getCourseCode());
            if (course != null) {
                myCoursesTableModel.addRow(new Object[] {
                        course.getCourseCode(),
                        course.getCourseName(),
                        course.getCredit(),
                        course.getInstructorUsername()
                });
            }
        }
    }

    // ── Enhancement 4: Grade Distribution Chart (Instructor tab) ────────────

    /**
     * Builds the Grade Distribution tab for the Instructor dashboard.
     * Requires JFreeChart JAR on the classpath; degrades gracefully if absent.
     */
    private JPanel createGradeChartTab() {
        JPanel wrapper = new JPanel(new BorderLayout(8, 8));
        wrapper.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 4));
        top.add(new JLabel("Select course:"));
        JComboBox<String> combo = new JComboBox<>();
        dataStore.getCoursesByInstructor(currentUser.getUsername())
                .forEach(c -> combo.addItem(c.getCourseCode()));
        top.add(combo);
        wrapper.add(top, BorderLayout.NORTH);

        JPanel chartHolder = new JPanel(new BorderLayout());
        wrapper.add(chartHolder, BorderLayout.CENTER);

        Runnable refresh = () -> {
            String code = (String) combo.getSelectedItem();
            chartHolder.removeAll();
            if (code != null) {
                try {
                    // GradeDistributionChart is in the same ui package
                    chartHolder.add(GradeDistributionChart.buildPanel(code));
                } catch (NoClassDefFoundError ex) {
                    // JFreeChart JAR not on classpath — show instructions instead
                    JLabel msg = new JLabel(
                            "<html><center>JFreeChart not found.<br>" +
                                    "Add <b>jfreechart-1.5.4.jar</b> to your classpath to enable this chart.</center></html>",
                            SwingConstants.CENTER);
                    chartHolder.add(msg);
                }
            }
            chartHolder.revalidate();
            chartHolder.repaint();
        };

        combo.addActionListener(e -> refresh.run());
        if (combo.getItemCount() > 0)
            refresh.run();
        return wrapper;
    }

    // ── Enhancement 5: PDF Transcript export ─────────────────────────────────

    private JPanel createTranscriptPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        gpaLabel = new JLabel("GPA: 0.00");
        gpaLabel.setFont(new Font("Arial", Font.BOLD, 16));
        gpaLabel.setForeground(new Color(50, 50, 150));
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        topPanel.add(gpaLabel);
        panel.add(topPanel, BorderLayout.NORTH);

        String[] columnNames = { "Course Code", "Course Name", "Credit",
                "Midterm", "Final", "Average", "Letter Grade" };
        transcriptTableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int r, int c) {
                return false;
            }
        };
        JTable transcriptTable = new JTable(transcriptTableModel);
        transcriptTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        transcriptTable.getTableHeader().setReorderingAllowed(false);

        // Enhancement 2: live search on transcript
        TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(transcriptTableModel);
        transcriptTable.setRowSorter(sorter);

        JPanel searchBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 4));
        searchBar.add(new JLabel("🔍 Search:"));
        JTextField searchField = new JTextField(16);
        searchBar.add(searchField);
        searchField.getDocument().addDocumentListener(new DocumentListener() {
            private void filter() {
                String t = searchField.getText().trim();
                sorter.setRowFilter(t.isEmpty() ? null : RowFilter.regexFilter("(?i)" + t));
            }

            public void insertUpdate(DocumentEvent e) {
                filter();
            }

            public void removeUpdate(DocumentEvent e) {
                filter();
            }

            public void changedUpdate(DocumentEvent e) {
                filter();
            }
        });

        JPanel centerPanel = new JPanel(new BorderLayout(0, 4));
        centerPanel.add(searchBar, BorderLayout.NORTH);
        centerPanel.add(new JScrollPane(transcriptTable), BorderLayout.CENTER);
        panel.add(centerPanel, BorderLayout.CENTER);

        transcriptTableModel = transcriptTableModel; // Already assigned, but for clarity
        refreshTranscript();

        // Enhancement 5: PDF Export button
        JButton exportBtn = new JButton("📄 Export PDF Transcript");
        exportBtn.setBackground(new Color(70, 130, 180));
        exportBtn.setForeground(Color.WHITE);
        exportBtn.setFocusPainted(false);
        exportBtn.addActionListener(e -> {
            StudentProfile profile = dataStore.findStudentProfileByUsername(currentUser.getUsername());
            String defaultName = (profile != null
                    ? profile.getFullName().replace(" ", "_")
                    : currentUser.getUsername()) + "_transcript.pdf";

            JFileChooser fc = new JFileChooser();
            fc.setSelectedFile(new File(defaultName));
            fc.setFileFilter(
                    new javax.swing.filechooser.FileNameExtensionFilter("PDF Files", "pdf"));

            if (fc.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
                String path = fc.getSelectedFile().getAbsolutePath();
                try {
                    String result = TranscriptExporter.export(currentUser.getUsername(), path);
                    JOptionPane.showMessageDialog(this, result, "Export",
                            JOptionPane.INFORMATION_MESSAGE);
                } catch (NoClassDefFoundError ex) {
                    JOptionPane.showMessageDialog(this,
                            "iText7 JARs not found.\n" +
                                    "Add kernel-7.2.5.jar, layout-7.2.5.jar, io-7.2.5.jar, " +
                                    "commons-7.2.5.jar to your classpath.",
                            "Missing Library", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        JPanel south = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        south.add(exportBtn);
        panel.add(south, BorderLayout.SOUTH);

        return panel;
    }

    // ── Utility ──────────────────────────────────────────────────────────────

    private void logout() {
        currentUser = null;
        cardLayout.show(mainPanel, LOGIN_CARD);
        JOptionPane.showMessageDialog(this,
                "You have been logged out successfully.",
                "Logout",
                JOptionPane.INFORMATION_MESSAGE);
    }

    // ==================== Main Method ====================

    public static void main(String[] args) {
        // Fallback: use the system L&F since FlatLaf is not in the classpath
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }

        SwingUtilities.invokeLater(() -> {
            UniversityAutomationApp app = new UniversityAutomationApp();
            app.setVisible(true);
        });
    }

    private void refreshTranscript() {
        if (transcriptTableModel == null || currentUser == null)
            return;
        transcriptTableModel.setRowCount(0);

        List<GradeRecord> grades = dataStore.getGradesByStudent(currentUser.getUsername());
        for (GradeRecord grade : grades) {
            Course course = dataStore.findCourse(grade.getCourseCode());
            if (course != null) {
                transcriptTableModel.addRow(new Object[] {
                        course.getCourseCode(),
                        course.getCourseName(),
                        course.getCredit(),
                        String.format("%.2f", grade.getMidterm()),
                        String.format("%.2f", grade.getFinalExam()),
                        String.format("%.2f", grade.calculateAverage()),
                        grade.getLetterGrade()
                });
            }
        }

        double gpa = dataStore.calculateGPA(currentUser.getUsername());
        gpaLabel.setText(String.format("GPA: %.2f", gpa));
    }
}