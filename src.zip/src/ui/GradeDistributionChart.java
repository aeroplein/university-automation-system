package ui;

import javax.swing.*;
import java.awt.*;

public class GradeDistributionChart {

    /**
     * Builds a panel containing the grade distribution chart.
     * Since JFreeChart is an external dependency not present in this project,
     * this implementation provides a placeholder message and notifies about missing capability.
     */
    public static JPanel buildPanel(String courseCode) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(Color.WHITE);
        
        JLabel label = new JLabel("<html><center><h2>Grade Distribution for " + courseCode + "</h2>" +
                "<p>Chart visualization requires <b>JFreeChart</b> library.</p>" +
                "<p>Please add jfreechart-1.5.4.jar to your classpath.</p></center></html>", 
                SwingConstants.CENTER);
        
        panel.add(label, BorderLayout.CENTER);
        return panel;
    }
}
