package model;

/**
 * StudentProfile class stores detailed information about students
 */
public class StudentProfile {
    private String studentId;
    private String fullName;
    private String department;
    private int year;
    private String username; // Links to User.username

    // Constructors
    public StudentProfile() {
    }

    public StudentProfile(String studentId, String fullName, String department, int year, String username) {
        this.studentId = studentId;
        this.fullName = fullName;
        this.department = department;
        this.year = year;
        this.username = username;
    }

    // Getters and Setters
    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * Converts student profile to CSV format for file persistence
     * Format: studentId,fullName,department,year,username
     */
    public String toFileString() {
        return String.format("%s,%s,%s,%d,%s",
                studentId != null ? studentId : "",
                fullName != null ? fullName.replace(",", ";") : "",
                department != null ? department.replace(",", ";") : "",
                year,
                username != null ? username : "");
    }

    /**
     * Creates a StudentProfile object from CSV string
     */
    public static StudentProfile fromFileString(String line) {
        if (line == null || line.trim().isEmpty()) {
            return null;
        }
        
        String[] parts = line.split(",", 5);
        if (parts.length >= 5) {
            try {
                return new StudentProfile(
                        parts[0].trim(),
                        parts[1].replace(";", ",").trim(),
                        parts[2].replace(";", ",").trim(),
                        Integer.parseInt(parts[3].trim()),
                        parts[4].trim()
                );
            } catch (NumberFormatException e) {
                System.err.println("Error parsing student year: " + line);
                return null;
            }
        }
        return null;
    }

    @Override
    public String toString() {
        return "StudentProfile{" +
                "studentId='" + studentId + '\'' +
                ", fullName='" + fullName + '\'' +
                ", department='" + department + '\'' +
                ", year=" + year +
                ", username='" + username + '\'' +
                '}';
    }
}
